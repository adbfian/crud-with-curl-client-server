<?php
function URLTarget($url){
     $data = curl_init();
     curl_setopt($data, CURLOPT_RETURNTRANSFER, 1);
     curl_setopt($data, CURLOPT_URL, $url);
     $hasil = curl_exec($data);
     curl_close($data);
     return $hasil;
}

$Code = URLTarget('http://server.com/cloud/index.php/client');
echo $Code;
?>